@extends('admin.master')
@section('content')

    <div class="container-fluid">
        <div class="row dash-row">
            <div class="col-xl-4">
                <div class="stats stats-primary">
                    <h3 class="stats-title"> Total User </h3>
                    <div class="stats-content">
                        <div class="stats-icon">
                            <i class="fas fa-user"></i>
                        </div>
                        <div class="stats-data">
                            <div class="stats-number">223</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4">
                <div class="stats stats-success ">
                    <h3 class="stats-title"> Today's Sale (Mobile Bankings) </h3>
                    <div class="stats-content">
                        <div class="stats-icon">
                            <i class="fas fa-money-bill-alt"></i>
                        </div>
                        <div class="stats-data">
                            <div class="stats-number">29000</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4">
                <div class="stats stats-danger">
                    <h3 class="stats-title"> Total Pending </h3>
                    <div class="stats-content">
                        <div class="stats-icon">
                            <i class="fas fa-phone"></i>
                        </div>
                        <div class="stats-data">
                            <div class="stats-number">77</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop
