<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Operator;
use Illuminate\Http\Request;

class OperatorController extends Controller
{
    public function index()
    {
        $operators=Operator::all();
        return view('admin.layouts.operator.list',compact('operators'));
    }

    public function createForm()
    {
        return view('admin.layouts.operator.create');
    }

    public function create(Request $request)
    {
        $request->validate([
            'name'=>'required',
            'opcode'=>'required'
        ]);

        Operator::create([
            'name'=>$request->name,
            'opcode'=>$request->opcode,
            'description'=>$request->description,
        ]);

        return redirect()->back()->with('message','Operator Created Successfully');
    }
}
