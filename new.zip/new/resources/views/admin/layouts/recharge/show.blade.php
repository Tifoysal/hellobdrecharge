@extends('backend.master')

@section('content')

    <div class="block-content block-content-full">
        <div class="form-group">
            <div class="row">
            <div class="col-md-6">
                <label for="sender">Sender</label>
                <p>{{$recharge_data->user->first_name}}  {{$recharge_data->user->last_name}}</p>
                <label for="trx">Transaction ID</label>
                <p>{{$recharge_data->transaction_id}}</p>
            </div>
            <div class="col-md-6">
                <label for="sf">Sent From</label>
                <p>{{$recharge_data->sent_from}}</p>
                <label for="ra">Requested Amount</label>
                <p>{{$recharge_data->amount}}</p>
            </div>
            </div>


            <label for="">Receipt</label>
            <img class="img-responsive img-thumbnail" src="{{url('/uploads/receipts/'.$recharge_data->receipt)}}" alt="">
        </div>
    </div>
@stop
