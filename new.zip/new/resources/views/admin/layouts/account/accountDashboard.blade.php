
@extends('admin.master')

@section('content')
    <div class="pull-left">
        <h3>Account</h3>
        <?php
        $userType = Auth::user()->type;
        ?>
    </div>
        <div class="row">

                @if($userType=='admin')

                    <div class="col-md-3 col-sm-3">
                        <select class="form-control acu" name="userId" id="acu">
                            <option value="">-- Select User --</option>
                            <option value="allusers">All Users</option>
                            @foreach($userList as $ul)
                                <option value="{{$ul->id}}">{{$ul->username}}</option>
                            @endforeach
                        </select>
                    </div>
                @endif
                <div class="col-md-3 col-sm-3">
                    <div class='input-group date' id='datetimepicker1'>
                        <input type='text' class="form-control" name="dateFrom" value="{{$from}}" />
                        <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                    </div>

                </div>
                <div class="col-md-2 col-sm-2">
                    <div class='input-group date' id='datetimepicker2'>
                        <input type='text' class="form-control" name="dateTo" value="{{$to}}" />
                        <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                    </div>
                </div>
                <div class="col-md-1 col-sm-1">
                    <button type="submit" style="width: 80px; margin-top: 0px;" class="btn btn-info btn-mar form-control">
                        <i class="fa fa-search"></i>
                    </button>
                </div>
{{--                @if($userType=='user')--}}
{{--                    <div class="col-md-1 col-sm-1">--}}
{{--                        <a href="{{route('balance.transfer')}}" style="width: 170px; margin-top: 0px;" class="btn btn-success btn-mar form-control">--}}
{{--                            Balance Transfer <i class="glyphicon glyphicon-plus"></i>--}}
{{--                        </a>--}}
{{--                    </div>--}}
{{--                @endif--}}

        </div>





        <div class="row m-3 content-panel" >
        <table class="table table-hover">
            <thead>
            <tr>
                <th class="">#</th>
                <th>Name</th>
                <th>Date Time</th>
                <th>Credit</th>
                <th>Debit</th>
                <th>Closing Balance</th>
            </tr>
            </thead>
            <tbody>

            @foreach($tnx as $key=>$tnxData)
                <tr>
                    <td>{{$key+1}}</td>

                    <td>{{$tnxData->user->username}}</td>
                    <td>{{$tnxData->created_dt}}</td>
                    <td>
                        @if($tnxData->transaction_head == "CREDIT")
                           {{$tnxData->amount}}
                        @endif
                    </td>
                    <td>
                        @if($tnxData->transaction_head == "DEBIT")
                        {{$tnxData->amount}}
                        @endif
                    </td>
                    <td>{{$tnxData->current_balance}}</td>
                </tr>
            @endforeach

            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td><b>Total :</b></td>
                <td colspan="" class=""><b>{{$tnx->sum('current_balance')}}</b></td>
            </tr>

            </tbody>
        </table>
    {{$tnx->links()}}
        </div>
        @endsection
        @push('script')
            <script type="text/javascript">
                $(function () {
                    $('#datetimepicker1').datepicker();
                });
                $(function () {
                    $('#datetimepicker2').datepicker();
                });

                $('#acop').change(function(){
                    $('#acu option:first').prop('selected', 'selected');
                });


                $('#acu').change(function(){
                    $('#acop option:first').prop('selected', 'selected');
                });

            </script>
    @endpush

