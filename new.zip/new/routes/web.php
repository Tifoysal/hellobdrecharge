<?php

Route::get('/', function () {
    return view('frontend.home');
})->name('home');

Route::get('/docs', function () {
    return view('documentation.index');
});

//Auth::routes();
//Route::get('/home', 'HomeController@index')->name('home');
Route::get('/login', 'Admin\UsersController@login')->name('login');
Route::post('/login', 'Admin\UsersController@doLogin')->name('do.login');

Route::group(['middleware' => 'auth','namespace'=>'Admin'], function () {

    //request
    Route::get('/request/list', 'RequestController@index')->name('request.index');
    Route::get('/request/create', 'RequestController@create')->name('request.create');
    Route::get('/request/create/mbanking', 'RequestController@mBankingRequest')->name('request.mBanking');
    Route::post('/request/store/{type}', 'RequestController@store')->name('request.store');
    Route::get('/request/show/{id}', 'RequestController@requestDetails')->name('request.show');
    Route::get('/request/update/{id}', 'RequestController@requestUpdateForm')->name('request.edit');
    Route::put('/request/update/{id}', 'RequestController@requestUpdate')->name('request.update');
//data recharge
    Route::get('/request/data/list', 'RequestController@dataIndex')->name('request.data.index');
    Route::get('/request/data/create', 'RequestController@dataCreate')->name('request.data.create');
//mobile banking
    Route::get('/request/mBanking/list', 'RequestController@mBankingIndex')->name('mBanking.index');
    Route::get('/request/mBanking/create', 'RequestController@mBankingCreate')->name('mBanking.create');
    Route::get('/request/mBanking/store', 'RequestController@mBankingRequest')->name('mBanking.request');


//    Route::group(['middleware' => 'admin'], function () {
    Route::get('/logout', 'UsersController@logout')->name('logout');

    //user management
    Route::get('/admin', 'HomeController@index')->name('dashboard');
    Route::get('admin/users/data', 'UsersController@data')->name('users.data');
    Route::resource('admin/users', 'UsersController');
    Route::any('admin/users/add_balance/{id}', 'UsersController@addBalance')->name('users.add_balance');
    Route::put('/admin/user/update-password','UsersController@updatePassword')->name('admin.update.password');
    //account history
    Route::get('admin/account/list', 'AccountController@index')->name('account');
    Route::any('admin/account/search', 'AccountController@Search');

    //package
    Route::get('admin/package/list', 'PackageController@index')->name('package.list');
    Route::get('admin/package/create', 'PackageController@createForm')->name('package.create');
    Route::post('admin/package/create', 'PackageController@create')->name('package.create');
    Route::get('admin/package/edit/{id}', 'PackageController@edit')->name('package.edit');
    Route::put('admin/package/update/{id}', 'PackageController@update')->name('package.update');

    //operator
    Route::get('admin/operator/list', 'OperatorController@index')->name('operator.list');
    Route::get('admin/operator/create', 'OperatorController@createForm')->name('operator.create');
    Route::post('admin/operator/create', 'OperatorController@create')->name('operator.create');


    Route::post('admin/inbox/assign', 'InboxController@assign_sms')->name('assignSMS');
    Route::get('admin/inbox', 'InboxController@index')->name('inbox.index');
    Route::get('admin/inbox/data', 'InboxController@data')->name('inbox.data');
    Route::get('admin/inbox/search', 'InboxController@search')->name('inbox.search');


    Route::get('admin/operators/data', 'OperatorsController@data')->name('operators.data');
    Route::any('admin/operators/add_balance/{id}',
        'OperatorsController@addBalance')->name('operators.add_balance');
    Route::resource('admin/operators', 'OperatorsController');

    Route::post('admin/update', 'TransactionsController@Update')->name('status.update');
    Route::get('admin/transactions/allTnxdata',
        'TransactionsController@allTnxdata')->name('transactions.allTnxdata');
    Route::get('admin/transactions/{id}', 'TransactionsController@show')->name('transactions.show');
    Route::resource('admin/transactions', 'TransactionsController');

    Route::get('admin/reports/balancemgmt', 'ReportsController@balanceMgmt')->name('reports.balanceMgmt');

//    });

    Route::get('user/balance/transfer', 'AccountController@balanceTransfer')->name('balance.transfer');
    Route::post('user/balance/transfer',
        'AccountController@balanceTransferPost')->name('balance.transfer_post');
//        Route::get('admin', 'AdminController@index')->name('admin');

    Route::get('admin/settings', 'SettingController@edit')->name('settings');
    Route::put('admin/settings', 'SettingController@update')->name('settings.update');

    Route::get('admin/reports', 'ReportsController@index')->name('reports.index');
    Route::get('admin/reports/data', 'ReportsController@data')->name('reports.data');


    Route::get('profile/{id}', 'UsersController@profile')->name('profile');
    Route::put('profile/{id}', 'UsersController@profileUpdate')->name('profile.update');


//    Route::get('admin/settings/powerload', 'Settings\SettingsController@powerload')->name('powerload');
//    Route::get('admin/settings/powerload/data', 'Settings\SettingsController@data')->name('powerload.data');

//    Route::resource('admin/account', 'AccountController');
//    Route::resource('request', 'RequestController');
    Route::resource('admin/sendrequest', 'RequestController');
    Route::get('admin/sendrequest/data', 'TransactionsController@data')->name('sendrequest.data');

});


