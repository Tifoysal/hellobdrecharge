<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Package;
use App\Models\Transaction;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Mockery\Exception;

class RequestController extends Controller
{
    public function index(Request $request)
    {
        $requests = Transaction::all();
//        dd($requests);
        return view('admin.layouts.request.list', compact('requests'));
    }

    public function create()
    {
        return view('admin.layouts.request.form');
    }

    public function dataIndex()
    {
        $requests = Transaction::where('trx_type', 'DR')->get();
//        dd($requests);
        return view('admin.layouts.request.data_recharge_list', compact('requests'));
    }

    //data recharge start here
    public function dataCreate()
    {
        $packages = Package::where('status', 'active')->get();
        return view('admin.layouts.request.data_recharge_form', compact('packages'));
    }

    //mobile banking start here
    public function mBankingCreate()
    {
        return view('admin.layouts.request.mbanking_request_form');
    }

    public function mBankingIndex()
    {
        $requests=Transaction::where('trx_type','MB')->get();
        return view('admin.layouts.request.mbanking_list',compact('requests'));
    }

    //request start here
    public function store(Request $_post, $type)
    {
        if ($type == 'recharge') {
            $_post->validate([
                'req_mobile' => 'required|size:11',
                'req_amount' => 'required|numeric',
                'req_type'   => 'required',
                'pin'        => 'required',
            ]);
        } else {
            $_post->validate([
                'req_mobile' => 'required|size:11',
                'req_type'   => 'required',
                'pin'        => 'required',
                'package_id' => 'required',
            ]);
        }

        if (auth()->user()->status === 'active') {
            if ($type == 'recharge') {
                $requested_amount = (int)$_post['req_amount'];
                $trx_type='RE';
            } else {
                $package=Package::find($_post->package_id);
//                dd($package);
                $requested_amount = $package->vendor_charge;
                $trx_type='DR';
            }

            $userId = auth()->user()->id;
            $cb = (double)auth()->user()->balance;
            $numberLength = strlen($_post['req_mobile']);

            if ($cb >= $requested_amount) {
                if ($numberLength === 11) {
                    if (auth()->user()->pin === $_post['pin']) {

                        $telco = $_post['req_operator'];

//                    if ($telco == '47001' or $telco == '47002' or $telco == '47003' or $telco == '47004' or $telco == '47007') {
                        try {
                            DB::beginTransaction();
                            $recharge = Transaction::create([
                                'mobile'    => $_post['req_mobile'],
                                'user_id'   => $userId,
                                'amount'    => $requested_amount,
                                'type'      => $_post['req_type'],
                                'telco'     => $telco,
                                'status'    => 'pending',
                                'trx_type'  => $trx_type,
                                'tmp_trxid' => 'T' . date('Ymdhms'),
                            ]);
// send request to API and waiting for API response
                            //if true update $recharge->update([
                            //'status'=>'success'
                            //'transaction_id'=>$response->transaction_id
                            //])

                            // after sending request reduce balance from user account
                            $newBalance = $cb - $requested_amount;
                            //update user balance
                            auth()->user()->decrement('balance', (int)$requested_amount);
                            //update admin balance
                            User::find(1)->increment('balance', (int)$requested_amount);

                            DB::commit();
                            session()->flash('message', 'Request sent to server.');
                        } catch (Exception $e) {
                            DB::rollBack();
                            session()->flash('error', $e->getMessage());
                        }

//                    } else {
//                        session()->flash('error', 'Invalid Operator.');
//                    }
                    } else {
                        session()->flash('error', 'Invalid PIN.');
                    }
                } else {
                    session()->flash('error', 'Number Should be 11 digits.');
                }
            } else {
                session()->flash('error', 'You have not Enough Balance');
            }
        } else {
            session()->flash('error', 'Account Blocked.Please contact with Admin.');
        }

        return redirect()->back();
    }

    public function requestUpdate(Request $_post,$id)
    {
        $_post->validate([
            'pin'=>'required'
        ]);
        if((int)$_post->pin===(int)auth()->user()->pin)
        {
        $request=Transaction::find($id);
//        if($request->status=='pending'|| $request->status=='failed' && $_post->status=='cancel')
//        {
            $request->update([
                'status'=>'cancel'
            ]);
            return redirect()->back()->with('message','Transaction Updated Successfully.');
//        }
        }else
        {
         return  redirect()->back()->with('error','Invalid PIN.');
        }

//        $request = Transaction::with('user')->find($id);
//        return view('admin.layouts.request.recharge_request_update', compact('request'));
    }

    public function requestDetails($id)
    {
        $request = Transaction::with('user')->find($id);
        return view('admin.layouts.request.recharge_request_details', compact('request'));
    }

    public function requestUpdateForm($id)
    {
        $request = Transaction::with('user')->find($id);
        return view('admin.layouts.request.recharge_request_update', compact('request'));
    }

}
