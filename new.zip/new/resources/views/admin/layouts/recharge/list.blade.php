@extends('backend.master')

@section('content')

    <div class="block-content block-content-full">
        <div class="table-responsive">
            @if(session()->has('message'))
                <p class="alert alert-success"> {{session()->get('message')}}</p>
            @endif

                @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif
            <table class="table table-bordered table-striped table-vcenter">
                <thead>
                <tr>
                    <th class="text-center" style="width: 100px;">
                        Sl
                    </th>
                    <th>Sender</th>
                    <th style="width: 30%;">Transaction Id</th>
                    <th style="width: 15%;">Type</th>
                    <th style="width: 15%;">Deposited Account</th>
                    <th style="width: 15%;">Request Amount</th>
                    <th style="width: 15%;">Received Amount</th>
                    <th style="width: 15%;">Sent From</th>
                    <th style="width: 15%;">Approved By</th>
                    <th style="width: 15%;">Status</th>
                    <th class="text-center" style="width: 100px;">Actions</th>
                </tr>
                </thead>
                <tbody>
                @foreach($recharges as $key=>$recharge)
                    <tr>
                        <td class="font-w600">
                            {{$key+1}}
                        </td>
                        <td class="font-w600">
                            {{$recharge->user->first_name}}
                        </td>
                        <td>{{$recharge->transaction_id}}</td>
                        <td>
                            {{$recharge->type}}
                        </td>
                        <td>
                            {{$recharge->deposit_account}}
                        </td>
                        <td>
                            {{$recharge->amount}}
                        </td>
                        <td>
                            {{$recharge->received_amount}}
                        </td>
                        <td>
                            {{$recharge->sent_from}}
                        </td>
                        <td>
                            {{$recharge->updatedBy ? $recharge->updatedBy->first_name:''}}
                        </td>
                        <td>
                            <span class="badge badge-primary">{{$recharge->status}}</span>
                        </td>
                        <td class="text-center">
                            <div class="btn-group">
                                <a href="{{route('recharge.show',$recharge->id)}}" class="btn btn-sm btn-info js-tooltip-enabled" data-toggle="tooltip" title="" data-original-title="Delete">
                                    <i class="fa fa-eye"></i>
                                </a>
                                @if($recharge->status=='pending')
                                    <button id="edit" onclick="edit({{$recharge->id}})" data-toggle="modal" data-target="#exampleModal" class="btn btn-sm btn-primary js-tooltip-enabled" data-toggle="tooltip" title="" data-original-title="Edit">
                                        <i class="fa fa-check"></i>
                                    </button>

                                    <a data-confirm="Are you sure ?" href="{{route('recharge.cancel',$recharge->id)}}" class="btn btn-sm btn-danger js-tooltip-enabled" data-toggle="tooltip" title="" data-original-title="Delete">
                                        <i class="fa fa-times"></i>
                                    </a>

                                @endif

                            </div>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
            {{$recharges->links()}}
        </div>
    </div>


    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Verify</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="{{route('recharge.edit')}}" method="POST" role="form">
                    @csrf
                    <input type="hidden" value="" name="recharge_id" class="recharge_id" id="recharge_id">
                    <div class="modal-body">
                        <label for="pin">Please Enter PIN:</label>
                        <input id="pin" required type="password" class="form-control" name="pin" placeholder="Please Enter PIN">
                        <label for="received_amount">Enter Received Amount:</label>
                        <input id="received_amount" required type="number" class="form-control" name="received_amount" placeholder="Please Received Amount">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@stop

@section('js_after')
    <script>
        function edit(id) {
            $("#recharge_id").val(id);
        }


        $(document).on('click', ':not(form)[data-confirm]', function(e){
            if(!confirm($(this).data('confirm'))){
                e.stopImmediatePropagation();
                e.preventDefault();
            }
        });
    </script>
@stop
