@extends('admin.master')
@section('content')

    <div class="container-fluid content-panel">
        <div class="row dash-row">
            <div class="col-xl-4">
                <div class="stats stats-dark">
                    <h3 class="stats-title"> Total User </h3>
                    <div class="stats-content">
                        <div class="stats-icon">
                            <i class="fas fa-user"></i>
                        </div>
                        <div class="stats-data">
                            <div class="stats-number">{{$user}}</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4">
                <div class="stats stats-success ">
                    <h3 class="stats-title"> Today's Sale (Mobile Banking) </h3>
                    <div class="stats-content">
                        <div class="stats-icon">
                            <i class="fas fa-money-bill-alt"></i>
                        </div>
                        <div class="stats-data">
                            <div class="stats-number">{{$todays_mbanking}}</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4">
                <div class="stats stats-warning">
                    <h3 class="stats-title"> Today's Sale (Recharge) </h3>
                    <div class="stats-content">
                        <div class="stats-icon">
                            <i class="fas fa-mobile"></i>
                        </div>
                        <div class="stats-data">
                            <div class="stats-number">{{$todays_recharge}}</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row dash-row">
            <div class="col-xl-4">
                <div class="stats stats-info">
                    <h3 class="stats-title"> Total Pending </h3>
                    <div class="stats-content">
                        <div class="stats-icon">
                            <i class="fas fa-user"></i>
                        </div>
                        <div class="stats-data">
                            <div class="stats-number">34</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4">
                <div class="stats stats-primary ">
                    <h3 class="stats-title">Total Success </h3>
                    <div class="stats-content">
                        <div class="stats-icon">
                            <i class="fas fa-money-bill-alt"></i>
                        </div>
                        <div class="stats-data">
                            <div class="stats-number">23</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4">
                <div class="stats stats-danger">
                    <h3 class="stats-title"> Total Sale</h3>
                    <div class="stats-content">
                        <div class="stats-icon">
                            <i class="fas fa-mobile"></i>
                        </div>
                        <div class="stats-data">
                            <div class="stats-number">3500</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop
