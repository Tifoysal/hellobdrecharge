<?php
namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        User::create([
            'username' => 'admin',
            'password' => bcrypt('123456'),
            'email' => 'admin@gmail.com',
            'phone_number' => '01700000000',
            'type' => 'admin',
            'balance' => 10000,
            'pin'=>'1234'
        ]);

        User::create([
            'username' => 'foysal',
            'password' => bcrypt('123456'),
            'email' => 'foysal@gmail.com',
            'phone_number' => '01600000000',
            'type' => 'user',
            'balance' =>0,
            'pin'=>'1122'
        ]);
    }
}
