@extends('admin.master')
@section('content')
    @foreach ($errors->all() as $error)
        <p class="alert alert-danger">{{ $error }}</p>
    @endforeach
    @if (session('message'))
        <div class="alert alert-success alert-dismissable">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">x</a>
            {{ session('message')}}
        </div>
    @endif
    <div class="col-md-12 content-panel">
    <form enctype="multipart/form-data" action="{{route('users.update',$user->id)}}" method="POST" role="form">
        @csrf
        @method('PUT')
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="exampleFormControlInput1">User Name</label>
                    <input required type="text" class="form-control" id="exampleFormControlInput1" value="{{$user->username}}" name="user_name">
                </div>
                <div class="form-group">
                    <label for="phone">Phone</label>
                    <input required name="phone_number" type="text" class="form-control" id="phone" value="{{$user->phone_number}}">
                </div>
            </div>

            <div class="col-md-6" style="">
                <div class="form-group" style="text-align: center">
                    <span><img style="width:150px;" src="{{url('/uploads/user/'.$user->image)}}" alt="User Image"></span>
                    <p style="padding: 20px;"><input type="file" name="file"></p>
                </div>
            </div>

        </div>


        <div class="row">

            <div class="col-md-6">
                <div class="form-group">
                    <label for="type">Change User Type</label>
                    <select class="form-control" id="type" name="type">
                        <option @if($user->user_type=='user') selected @endif value="user">End User</option>
                        <option @if($user->user_type=='admin') selected @endif value="admin">Admin</option>
                        <option @if($user->user_type=='vendor') selected @endif value="vendor">Vendor</option>
                        <option @if($user->user_type=='seller') selected @endif value="seller">Seller</option>
                        <option @if($user->user_type=='developer') selected @endif value="developer">Developer</option>

                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="balance">User Balance </label>
                    <input type="text" class="form-control" id="balance" name="balance" value="{{$user->balance}}" readonly>
                </div>
            </div>
        </div>



        <div class="form-group">
            <label for="type">Status</label>
            <select class="form-control" id="type" name="status">
                <option value="active" {{$user->status=='active' ? 'selected':''}}>Active</option>
                <option value="inactive" {{$user->status=='inactive' ? 'selected':''}} >Inactive</option>
                <option value="block" {{$user->status=='block' ? 'selected':''}} >Block</option>
            </select>
        </div>

        <button type="submit" class="btn btn-success mr-2">Update</button>
        <a href="{{route('users.data')}}" class="btn btn-primary">Back</a>
    </form>

        <hr>
        <div class="form-group">
            <h3>Update password</h3>
        <form action="{{route('admin.update.password')}}" method="post" role="form">
           @csrf
            @method('put')
            <div class="col-md-6">
                <div class="form-group">
                    <label for="password">Enter Password * </label>
                    <input required placeholder="Enter Password" type="password" class="form-control" id="password" name="password">
                </div>
                <div class="form-group">
                    <label for="pin">Enter PIN * </label>
                    <input required placeholder="Enter PIN" type="pin" class="form-control" id="pin" name="pin">
                </div>

                <button class="btn btn-success" type="submit">Update</button>
            </div>

        </form>
        </div>

    </div>
@stop
