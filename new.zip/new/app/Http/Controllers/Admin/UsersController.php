<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\UserBalance;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Mockery\Exception;
use Yajra\DataTables\DataTables;

class UsersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return void
     */
    public function login()
    {
        return view('admin.layouts.user.login');
    }

    public function doLogin(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'email'    => 'required',
            'password' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        $credentials = [
            'email'    => $request->input('email'),
            'password' => $request->input('password'),
        ];
//dd(auth()->guard('web')->attempt($credentials));
        try {

            if (auth()->attempt($credentials)) {

                if (auth()->user()->status === 'active') {

                    Toastr::success('Login Successful', 'success', ["positionClass" => "toast-top-right"]);

                    return redirect()->route('dashboard');

                } else {
                    Auth::logout();
                    Toastr::warning('Your account is deactivated.', 'warning', ["positionClass" => "toast-top-right"]);
                    return redirect()->back();
                }

            } else {

                //  Toastr::error("Invalid Credentials !", 'error', ["positionClass" => "toast-top-right"]);
                return redirect()->back()->withErrors('Invalid credentials');
            }
        } catch (\Exception $e) {
            Toastr::error($e->getMessage(), 'error', ["positionClass" => "toast-top-right"]);
            return redirect()->back();
        }
    }

    public function logout()
    {
        auth()->logout();
        Toastr::success('Logged out successfully.', 'success', ["positionClass" => "toast-top-right"]);
        return redirect()->route('login');
    }


    public function data()
    {
        $users = User::paginate(10);

        return view('admin.layouts.user.list', compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return void
     */
    public function create()
    {
        $user = '';
        return view('admin.layouts.user.create', compact('user'));
    }

    public function addBalance(Request $request, int $id)
    {

        if ($_POST) {
            try {
                $request->validate([
                    'type'   => 'required',
                    'amount' => 'required',
                    'pin'    => 'required',
                ]);
                $userId = Auth::user()->id;
                $currentBal = User::select('balance')
                    ->find($id);

                $req_pin = request()->input('pin');
                $admin = User::where('pin', $req_pin)
                    ->where('id', $userId)
                    ->first();
                if ($admin) {
                    if ($userId != $id) {
                        $ab = auth()->user()->balance;

                        $reqBal = (float)request()->input('amount');
                        $cb = (float)$currentBal->balance;

                        // print_r($balance.'-'.$reqBal);exit();
                        $tnxhead = request()->input('type');

                        if ($tnxhead == 'sub') {
                            if ($cb >= $reqBal) {//check user has enough balance
                                $th = 'DEBIT';
                                $cb = $cb - $reqBal;
                                $adminb = $ab + $reqBal;
                                $adminTnxhead = 'CREDIT';
                                DB::beginTransaction();
                                UserBalance::create([
                                    'user_id'          => $id,
                                    'transaction_head' => $th,
                                    'amount'           => $reqBal,
                                    'current_balance'  => $cb,
                                    'created_by'       => $userId
                                ]);

                                UserBalance::create([
                                    'user_id'          => $userId,
                                    'transaction_head' => $adminTnxhead,
                                    'amount'           => $reqBal,
                                    'current_balance'  => $adminb,
                                    'created_by'       => $userId
                                ]);
                                User::find($id)->decrement('balance', $reqBal);
                                User::find($userId)->increment('balance', $reqBal);
                                DB::commit();
                                session()->flash('message', 'Balance Debited from User!');
                                return redirect()->back();
                            } else {
                                session()->flash('error', 'Insufficient User Balance!');
                                return redirect()->back();
                            }
                        } else {
                            if ($ab >= $reqBal) {
                                $th = 'CREDIT';
                                $cb = $cb + $reqBal;
                                $adminb = $ab - $reqBal;
                                $adminTnxhead = 'DEBIT';
                                DB::beginTransaction();
                                UserBalance::create([
                                    'user_id'          => $id,
                                    'transaction_head' => $th,
                                    'amount'           => $reqBal,
                                    'current_balance'  => $cb,
                                    'created_by'       => $userId
                                ]);

                                UserBalance::create([
                                    'user_id'          => $userId,
                                    'transaction_head' => $adminTnxhead,
                                    'amount'           => $reqBal,
                                    'current_balance'  => $adminb,
                                    'created_by'       => $userId
                                ]);
                                User::find($id)->increment('balance', $reqBal);
                                User::find($userId)->decrement('balance', $reqBal);
                                DB::commit();
                                session()->flash('message', 'Balance Credited to User!');
                                return redirect()->back();
                            } else {
                                session()->flash('error', 'Insufficient Admin Balance Balance!');
                                return redirect()->back();
                            }
                        }

                    } else {
                        session()->flash('error', 'Admin Cannot Update Balance By itself!');
                        return redirect()->back();
                    }
                } else {
                    session()->flash('error', 'Invalid PIN !');
                    return redirect()->back();
                }
            } catch (Exception $e) {
                DB::rollback();
                session()->flash('error', $e->getMessage());
                return redirect()->back();
            }


            // print_r($currentBal->current_balance);exit();
        }
        $user = User::find($id);
        return view('admin.layouts.user.balance', compact('user'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return void
     */
    public function store(Request $request)
    {

        $this->validate($request, [
            'username'     => 'required',
            'email'        => 'required',
            'password'     => 'required',
//            'pin'          => 'required|max:4|min:4|unique:users',
            'phone_number' => 'required',
        ]);

        $data = $request->except('password');// this will return all form data except
        $data['password'] = bcrypt($request->password);
        User::create($data);

        return redirect()->back()->with('message', 'User Created Successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     *
     * @return void
     */
    public function show($id)
    {
        $user = User::findOrFail($id);

        return view('admin.users.show', compact('user'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     *
     * @return void
     */
    public function edit($id)
    {
        $user = User::findOrFail($id);
        return view('admin.layouts.user.edit', compact('user'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     *
     * @return void
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'status'       => 'required',
            'type'         => 'required',
            'phone_number' => 'required',
            'user_name'    => 'required'
        ]);
        $user = User::findOrFail($id);
        $file_name = '';

        if ($request->hasFile('file')) {
            $avatar = $request->file('file');

            if ($avatar->isValid()) {
                $file_name = uniqid("user_", true).mt_rand(10,10).'.'.$avatar->getClientOriginalExtension();
                $avatar->storeAs('user', $file_name);
            }
        }else
        {
            $file_name=$user->image;
        }

        $user->update([
            'status'       => $request->status,
            'type'         => $request->type,
            'phone_number' => $request->phone_number,
            'user_name'    => $request->user_name,
            'image'        => $file_name,
        ]);

        return redirect()->back()->with('message', 'User updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     *
     * @return void
     */
    public function destroy($id)
    {
        // User::destroy($id);

        return redirect('admin/users')->with('flash_message', 'Permission Protected!');
    }

    public function profile($id)
    {
        $user = User::findOrFail($id);
        if ($user->id == Auth::user()->id) {
            return view('admin.profile', compact('user'));
        }

        return redirect()->route('admin');
    }

    public function updatePassword(Request $request)
    {
        try {
            $this->validate($request,
                [
                    'password' => 'required'
                ]);

            if ((int)$request->pin === (int)auth()->user()->pin) {
                User::find(auth()->user()->id)->update(['password' => Hash::make($request->password)]);
                Toastr::success('Password Updated.', 'success', ["positionClass" => "toast-top-right"]);
            } else {
                Toastr::error('Invalid PIN', 'error');
            }

            return redirect()->back();

        } catch (Exception $e) {
            Toastr::error($e->getMessage(), 'error', ["positionClass" => "toast-top-right"]);
            return redirect()->back();
        }


    }

    private function pr($data)
    {
        echo "<pre>";
        print_r($data);
        exit;
    }
}
