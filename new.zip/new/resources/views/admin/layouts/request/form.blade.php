@extends('admin.master')
@section('content')
    <div class="row">

        <div class="col-md-12">
            <h3>Send Request </h3>

            <div class="col-md-3">
            </div>
            <div class="col-md-6">
                @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @elseif(session()->has('message'))
                    <div class="alert alert-success">
                        {{ session('message') }}
                    </div>
                @elseif(session()->has('error'))
                    <div class="alert alert-warning">
                        {{ session('error') }}
                    </div>
                @endif
                <div class="content-panel">

                    <form action="{{route('request.store','recharge')}}" method="post" role="form">

                        @csrf
                        <label>Enter Mobile NO * :</label>
                        <input class="form-control" type="number" name="req_mobile" id="req_mobile" required
                              value="01671111111" placeholder="01XXXXXXXXX">


                        <label>Enter Amount * :</label>
                        <input class="form-control" type="number" name="req_amount" id="req_amount" required
                               value="10" placeholder="Amount" min="5">


                        <label>Select Type * :</label>
                        <select class="form-control" name="req_type" required>
                            <option selected="selected" value="prepaid">Prepaid</option>
                            <option value="postpaid">PostPaid</option>
                        </select>


                        <label>Select Operator:</label>
                        <select class="form-control" name="req_operator" required="required">
                            <option selected="" value="">--Select Operator--</option>
                            <option selected="" value="GP">Grameenphone</option>
                            <option selected="" value="Robi">Robi</option>
                            <option selected="" value="Banglalink">Banglalink</option>
                            <option selected="" value="TeleTalk">Teletalk</option>
                            <option selected="" value="Airtel">Airtel</option>
                        </select>


                        <label>Enter PIN * :</label>
                        <input value="1234" class="form-control" type="password" name="pin" id="pin" required placeholder="pin">


                        <button type="submit" style="width: 100px; margin-top: 25px;"
                                class="btn btn-success btn-mar form-control"
                        onclick="clicked(event)">Send
                            <i class="fas fa-paper-plane"></i>
                        </button>
                        <a href="" style=" margin-left:10px;width: 100px; margin-top: 25px;" class="btn btn-danger">  <i class="fa fa-home" aria-hidden="true"></i>  Back</a>
                        <!-- <input type="submit" onclick="clicked(event)" /> -->
                    </form>
                </div>
            </div>
            <div class="col-md-3">
            </div>
        </div>

    </div>
@stop

@push('script')



    <script>
        function clicked(e) {
            var number = document.getElementById("req_mobile").value;
            var amount = document.getElementById("req_amount").value;
            // if(!confirm('Are you sure?'))e.preventDefault();
            if (!confirm('Confirm Request to Number: ' + number + ' ,and Amount: ' + amount + ' ?')) e.preventDefault();
        }
    </script>
@endpush
