<nav class="dash-nav-list">
    <a href="{{route('dashboard')}}" class="dash-nav-item">
        <i class="fas fa-home"></i> Dashboard </a>

        <div class="dash-nav-dropdown {{request()->is('request/*')?' show':''}}">
            <a href="#!" class="dash-nav-item dash-nav-dropdown-toggle">
                <i class="fas fa-paper-plane"></i> Request  </a>
            <div class="dash-nav-dropdown-menu">
                <a href="{{route('request.create')}}" class="dash-nav-dropdown-item">Recharge</a>
{{--                <a href="{{route('request.index')}}" class="dash-nav-dropdown-item">List</a>--}}
            </div>
            <div class="dash-nav-dropdown-menu">
                <a href="{{route('request.data.create')}}" class="dash-nav-dropdown-item">Data Recharge</a>
{{--                <a href="{{route('request.index')}}" class="dash-nav-dropdown-item">List</a>--}}
            </div>

            <div class="dash-nav-dropdown-menu show">
                {{--                <a href="{{route('request.create')}}" class="dash-nav-dropdown-item">New</a>--}}
                <a href="{{route('request.index')}}" class="dash-nav-dropdown-item">Recharge List</a>
            </div>
            <div class="dash-nav-dropdown-menu">
                <a href="{{route('mBanking.create')}}" class="dash-nav-dropdown-item">Mobile Banking</a>
             </div>
            <div class="dash-nav-dropdown-menu show">
                    <a href="{{route('mBanking.index')}}" class="dash-nav-dropdown-item">Mobile Banking List</a>
            </div>


        </div>

        <div class="dash-nav-dropdown {{request()->is('admin/user*')?' show':''}}">
            <a href="#!" class="dash-nav-item dash-nav-dropdown-toggle">
                <i class="fas fa-users"></i> Users </a>
            <div class="dash-nav-dropdown-menu">
                <a href="{{route('users.data')}}" class="dash-nav-dropdown-item">List</a>
            </div>
        </div>

        <div class="dash-nav-dropdown  {{request()->is('admin/account/*')?' show':''}}">
            <a href="#!" class="dash-nav-item dash-nav-dropdown-toggle">
                <i class="fas fa-file-invoice-dollar"></i> Account </a>
            <div class="dash-nav-dropdown-menu">
                <a href="{{route('account')}}" class="dash-nav-dropdown-item">Statement</a>
            </div>
        </div>


        <div class="dash-nav-dropdown {{request()->is('admin/package/*')?' show':''}}">
            <a href="#!" class="dash-nav-item dash-nav-dropdown-toggle">
                <i class="fas fa-list-ul"></i> Package </a>
            <div class="dash-nav-dropdown-menu">
                <a href="{{route('package.list')}}" class="dash-nav-dropdown-item">List</a>
            </div>
            <div class="dash-nav-dropdown-menu">
                <a href="{{route('package.create')}}" class="dash-nav-dropdown-item">Create</a>
            </div>
        </div>

    <div class="dash-nav-dropdown {{request()->is('admin/operator/*')?' show':''}}">
            <a href="#!" class="dash-nav-item dash-nav-dropdown-toggle">
                <i class="fas fa-list-ul"></i> Operator </a>
            <div class="dash-nav-dropdown-menu">
                <a href="{{route('operator.list')}}" class="dash-nav-dropdown-item">List</a>
            </div>
            <div class="dash-nav-dropdown-menu">
                <a href="{{route('operator.create')}}" class="dash-nav-dropdown-item">Create</a>
            </div>
        </div>




{{--    <div class="dash-nav-dropdown {{request()->is('admin/payment/*')?' show':''}}">--}}
{{--        <a href="#!" class="dash-nav-item dash-nav-dropdown-toggle">--}}
{{--            <i class="fas fa-money-check-alt"></i> Balance  </a>--}}
{{--        <div class="dash-nav-dropdown-menu">--}}
{{--            <a href="" class="dash-nav-dropdown-item">Add</a>--}}
{{--        </div>--}}
{{--    </div>--}}



    <div class="dash-nav-dropdown {{request()->is('admin/setting/*')?' show':''}}">
        <a href="#!" class="dash-nav-item dash-nav-dropdown-toggle">
            <i class="fas fa-sliders-h"></i> Setting  </a>
        <div class="dash-nav-dropdown-menu">
            <a href="{{route('settings')}}" class="dash-nav-dropdown-item">List</a>
        </div>
    </div>



</nav>
