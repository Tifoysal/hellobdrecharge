<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Transaction;
use App\Models\User;
use Carbon\Carbon;
use GuzzleHttp\Psr7\Request;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user=User::where('status','active')->count();
        $todays_recharge=Transaction::where('trx_type','RE')->where('status','success')->whereDate('s_datetime',carbon::today())->sum('amount');
        $todays_mbanking=Transaction::where('trx_type','MB')->where('status','success')->whereDate('s_datetime',carbon::today())->sum('amount');
        return view('admin.layouts.dashboard',compact('user','todays_recharge','todays_mbanking'));
    }

    public function registerForm()
    {
        dd("test");
        return view('auth.register');
    }

    protected function createUser(Request $request)
    {
        dd($request->all());
        $user = User::create([
            'username' => $data['name'],
            'email' => $data['email'],
            'phone_number' => $data['phone'],
            'password' => bcrypt($data['password']),
            'balance' => 0
        ]);
        DB::TABLE('users_balance')->insert(
            [
                'user_id' => $user->id,
                'amount' => 0,
                'transaction_head' => 'OB', //OB for opening Balance
                'created_by' => $user->id
            ]);

//        $user->assignRole('user');

        return redirect()->back();
    }
}
