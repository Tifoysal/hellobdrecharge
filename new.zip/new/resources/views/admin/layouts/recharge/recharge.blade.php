@extends('frontend.master')

@section('content')
    <div class="container container-tab">
        @if($errors->any())
            <div class="alert alert-danger">
                {{ $errors->first() }}
            </div>
        @endif
        @if(session()->has('message'))
            <p class="alert alert-success"> {{session()->get('message')}}</p>
        @endif
        <div class="row justify-content-left align-items-left">


            <div id="accordion" class="form-group col-12">
                <h2 class="mb-3 mb-sm-4 text-center">Payment</h2>
            {{--                <label class="mb-2">Payment Method:</label>--}}
            <!--Paypal-->
                {{--                    <div class="card rounded-0">--}}
                {{--                        <div class="card-header">--}}
                {{--                            <button class="btn collapsed" type="button" data-toggle="collapse" data-target="#paypal" aria-expanded="true" aria-controls="collapseOne">--}}
                {{--                                Paypal--}}
                {{--                            </button>--}}
                {{--                        </div>--}}

                {{--                        <div id="paypal" class="collapse" data-parent="#accordion">--}}
                {{--                            <div class="card-body">--}}

                {{--                            </div>--}}
                {{--                        </div>--}}
                {{--                    </div>--}}

                <div class="form-wrapper rounded">
                    <!--Wallet-->
                    <form action="{{route('recharge.post','mobile_wallet')}}" role="form" method="post">
                        @csrf()

                        <div class="card rounded-0">
                            <div class="card-header">
                                <button class="btn" type="button" data-toggle="collapse" data-target="#wallet" aria-expanded="false" aria-controls="collapseTwo">
                                    Mobile Wallet
                                </button>
                            </div>
                            <div id="wallet" class="collapse" data-parent="#accordion">
                                <div class="card-body">
                                    <div class="row text-left">
                                        <div class="form-group col-12">
                                            <label class="custom-control custom-radio">
                                                <input value="bkash" id="bkash" name="details[type]" type="radio" class="custom-control-input">
                                                <span class="custom-control-indicator"></span>
                                                <span class="custom-control-description">Bkash (Personal) (01911231501)</span>
                                            </label>
                                            <label class="custom-control custom-radio">
                                                <input value="rocket" id="rocket" name="details[type]" type="radio" class="custom-control-input">
                                                <span class="custom-control-indicator"></span>
                                                <span class="custom-control-description">Rocket (Agent) (018508502996)</span>
                                            </label>
                                            <label class="custom-control custom-radio">
                                                <input value="mcash" id="mcash" name="details[type]" type="radio" class="custom-control-input">
                                                <span class="custom-control-indicator"></span>
                                                <span class="custom-control-description">Mcash (Agent) (018508502996)</span>
                                            </label>
                                            <label class="custom-control custom-radio">
                                                <input value="surecash" id="sureCash" name="details[type]" type="radio" class="custom-control-input">
                                                <span class="custom-control-indicator"></span>
                                                <span class="custom-control-description">Sure Cash (Agent) (016771031701)</span>
                                            </label>
                                        </div>

                                        <div class="form-group col-12">
                                            <label class="mb-2">Amount:</label>
                                            <input name="details[amount]" required placeholder="Enter Amount" id="amount" type="text" class="form-control rounded-0 mb-2">
                                        </div>

                                        <div class="form-group col-12">
                                            <label class="mb-2">Sent From:</label>
                                            <input name="details[sent_from]" placeholder="Enter Payment from" id="from" type="text" class="form-control rounded-0 mb-2">
                                        </div>
                                        <div class="form-group col-12">
                                            <label class="mb-2">Transaction ID:</label>
                                            <input name="details[trx_number]" placeholder="Enter Transaction ID" id="transactionId" type="text" class="form-control rounded-0 mb-2">
                                        </div>
                                        <div class="form-group col-12 text-center">
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                    <!--Bank Payment-->
                    <form action="{{route('recharge.post','bank')}}" role="form" method="post" enctype="multipart/form-data">
                        @csrf()

                        <div class="card rounded-0">
                            <div class="card-header">
                                <button class="btn collapsed" type="button" data-toggle="collapse" data-target="#online" aria-expanded="false" aria-controls="collapseThree">
                                    Bank Payment
                                </button>
                            </div>
                            <div id="online" class="collapse" data-parent="#accordion">
                                <div class="card-body">
                                    <div class="row text-left">
                                        <div class="form-group col-12">
                                            <label class="custom-control custom-radio">
                                                <input value="prime_bank" id="prime_bank" name="details[type]" type="radio" class="custom-control-input">
                                                <span class="custom-control-indicator"></span>
                                                <span class="custom-control-description">
                                                   <p> Prime Bank Ltd. (14811060010814)</p>
                                                    <p>Nur International</p><p>SBC Tower Branch, Dhaka</p>
                                                </span>
                                            </label>
                                            <label class="custom-control custom-radio">
                                                <input value="brac" id="brac" name="details[type]" type="radio" class="custom-control-input">
                                                <span class="custom-control-indicator"></span>
                                                <span class="custom-control-description">
                                                   <p> Brac Bank Ltd. (1513202487310001)</p>
                                                    <p>Nur International</p><p>Graphic Building Brunch</p><p> Motijheel Dhaka</p>
                                                </span>
                                            </label>
                                            <label class="custom-control custom-radio">
                                                <input value="islami" id="islami" name="details[type]" type="radio" class="custom-control-input">
                                                <span class="custom-control-indicator"></span>
                                                <span class="custom-control-description">
                                                   <p> Islami Bank Ltd. (20503110100060402)</p>
                                                    <p>Nur International</p><p>Motijheel Branch, Dhaka</p>
                                                </span>
                                            </label>
                                            <label class="custom-control custom-radio">
                                                <input value="ucbl" id="ucbl" name="details[type]" type="radio" class="custom-control-input">
                                                <span class="custom-control-indicator"></span>
                                                <span class="custom-control-description">
                                                   <p> UCBL(0952101000012744)</p>
                                                    <p>Utility payments bd.</p><p>UCBL Corporate Branch</p><p> Gulshan, Dhaka.</p>
                                                </span>
                                            </label>
                                        </div>
                                        <div class="form-group col-12">
                                            <label class="mb-2">Amount:</label>
                                            <input name="details[amount]" required placeholder="Enter Amount" id="amount" type="text" class="form-control rounded-0 mb-2">
                                        </div>
                                        <div class="form-group col-12">
                                            <label class="mb-2">Account From:</label>
                                            <input name="details[sent_from]" placeholder="Enter your Account" id="account" type="text" class="form-control rounded-0 mb-2">
                                        </div>
                                        <div class="form-group col-12">
                                            <label class="mb-2">Transaction ID:</label>
                                            <input name="details[trx_number]" placeholder="Enter Transaction ID" id="transactionId2" type="text" class="form-control rounded-0 mb-2">
                                        </div>
                                        <div class="form-group col-12 custom-file">
                                            <input name="details[receipt]" type="file" class="custom-file-input" id="vehicleRegistration">
                                            <label class="custom-file-label" for="customFile">Attach Receipt</label>
                                        </div>
                                        <div class="form-group col-12 text-center">
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                    <!--Agent Banking-->
                    <form action="{{route('recharge.post','agent')}}" role="form" method="post" enctype="multipart/form-data">
                        @csrf()

                        <div class="card rounded-0">
                            <div class="card-header">
                                <button class="btn collapsed" type="button" data-toggle="collapse" data-target="#cash" aria-expanded="false" aria-controls="collapseThree">
                                    Agent Banking
                                </button>
                            </div>
                            <div id="cash" class="collapse" data-parent="#accordion">
                                <div class="card-body">
                                    <div class="row text-left">
                                        <div class="form-group col-12">
                                            <label class="custom-control custom-radio">
                                                <input value="dbbl_agent" id="dbbl_agent" name="details[type]" type="radio" class="custom-control-input">
                                                <span class="custom-control-indicator"></span>
                                                <span class="custom-control-description">
                                                   <p> DBBL (Agent) (7017019056509)</p>
                                                    <p>A k m Nurol Haq</p>
                                                </span>
                                            </label>

                                        </div>
                                        <div class="form-group col-12">
                                            <label class="mb-2">Amount:</label>
                                            <input name="details[amount]" required placeholder="Enter Amount" id="amount" type="text" class="form-control rounded-0 mb-2">
                                        </div>
                                        <div class="form-group col-12">
                                            <label class="mb-2">Account From:</label>
                                            <input name="details[sent_from]" placeholder="Enter your Account" id="account" type="text" class="form-control rounded-0 mb-2">
                                        </div>
                                        <div class="form-group col-12">
                                            <label class="mb-2">Transaction ID:</label>
                                            <input name="details[trx_number]" placeholder="Enter Transaction ID" id="transactionId2" type="text" class="form-control rounded-0 mb-2">
                                        </div>
                                        <div class="form-group col-12 custom-file">
                                            <input type="file" name="details[receipt]" class="custom-file-input" id="vehicleRegistration">
                                            <label class="custom-file-label" for="customFile">Attach Receipt</label>
                                        </div>
                                        <div class="form-group col-12 text-center">
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                </div>
            </div>


        </div>
    </div>

@stop
