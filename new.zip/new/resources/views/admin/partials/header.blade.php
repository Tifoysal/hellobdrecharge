<header class="dash-toolbar">
    <a href="#!" class="menu-toggle">
        <i class="fas fa-bars"></i>
    </a>

    <div class="tools">
        {{--<a href="https://github.com/HackerThemes/spur-template" target="_blank" class="tools-item">--}}
            {{--<i class="fab fa-github"></i>--}}
        {{--</a>--}}
{{--        <a href="#!" class="tools-item">--}}
{{--            <i class="fas fa-bell"></i>--}}
{{--            <i class="tools-item-count"></i>--}}
{{--        </a> --}}

        <div class="dropdown tools-item" style="width: 200px !important;">
            <a href="#" class="" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <img style="width: 50px;" src="{{url('/uploads/user/'.auth()->user()->image)}}" alt=""> {{auth()->user()->username}} ({{auth()->user()->balance}} .tk)
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenu1">
                <a class="dropdown-item" href="{{route('users.edit',auth()->user()->id)}}">Profile</a>
{{--                <p class="dropdown-item" href="#!">Current Balance: {{auth()->user()->balance}}</p>--}}
                <a class="dropdown-item" href="{{route('logout')}}">Logout</a>
            </div>
        </div>
    </div>
</header>
